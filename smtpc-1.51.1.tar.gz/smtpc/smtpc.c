#include "CSmtp.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <syslog.h>
#include <netdb.h>
#include <string.h>
#include <ctype.h>
#include <pwd.h>
#include <sys/ioctl.h>
#include "openssl/err.h"
#include "openssl/ssl.h"
#include <sys/time.h>
#include <uuid/uuid.h>


typedef struct {
	int	mime_style;
	int	mailport;
	int m_type;
	char	*from_addr;
	char	*mailhost;
	char	*recipient;
	char	*subject;
	char	*username;
	char	*password;
}smtp_conf;

extern char *optarg;

static int	verbose=0;
static int	need_auth=0;

static char table64[]=
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

void base64Encode(char *intext, char *output)
{
  unsigned char ibuf[3];
  unsigned char obuf[4];
  int i;
  int inputparts;

  while(*intext) {
    for (i = inputparts = 0; i < 3; i++) { 
      if(*intext) {
        inputparts++;
        ibuf[i] = *intext;
        intext++;
      }
      else
        ibuf[i] = 0;
    }

    obuf [0] = (ibuf [0] & 0xFC) >> 2;
    obuf [1] = ((ibuf [0] & 0x03) << 4) | ((ibuf [1] & 0xF0) >> 4);
    obuf [2] = ((ibuf [1] & 0x0F) << 2) | ((ibuf [2] & 0xC0) >> 6);
    obuf [3] = ibuf [2] & 0x3F;

    switch(inputparts) {
      case 1: /* only one byte read */
        sprintf(output, "%c%c==", 
            table64[obuf[0]],
            table64[obuf[1]]);
        break;
      case 2: /* two bytes read */
        sprintf(output, "%c%c%c=", 
            table64[obuf[0]],
            table64[obuf[1]],
            table64[obuf[2]]);
        break;
      default:
        sprintf(output, "%c%c%c%c", 
            table64[obuf[0]],
            table64[obuf[1]],
            table64[obuf[2]],
            table64[obuf[3]] );
        break;
    }
    output += 4;
  }
  *output=0;
}
/*
**  logging support
*/
void log(char *str, ...)
{
    va_list ap;
    char buf[1024];

    va_start(ap, str);
    vsprintf(buf, str, ap);
    dprintf("%s\n",buf);
    syslog(LOG_INFO,buf);
    va_end(ap);
    return;
}

void usage(void)
{
	puts("==========================================================");
	puts("Usage: ./smtpc [m:s:f:r:h:p:U:P:v] < files		");
	puts("	-m mime type						");
	puts("	-s subject						");
	puts("	-f from addr (if NULL use recipient)			");
	puts("	-r recipient						");
	puts("	-h mail server							");
	puts("	-p mail port (default=25)				");
	puts("	-U user name (ESMTP)					");
	puts("	-P password  (ESMTP)					");
	puts("	-v verbose   (DEBUG)					");
	puts("========================================================\n");
}
#if 1
int debuglog = 1;
void smtplog(char *format,...)
{
    va_list args;
    FILE *fp;
    time_t timep;
    struct tm *p;

    if(debuglog == 0)
        return;
    fp = fopen("/var/smtplog","a+");
    if(!fp){
        return;
    }
    
    time(&timep);
    p=localtime(&timep);
    va_start(args,format);
    vfprintf(fp,format,args);
    va_end(args);
    fflush(fp);
    fclose(fp);
}
#endif

int main(int argc, char **argv)
{
	bool bError = 0;

	char buf[BUFSIZ];
	struct sockaddr_in sin;
	struct hostent *hp;
	int s;
	int r;
	char *cp;
	smtp_conf conf;
	char enc_user[128];
	char enc_pw[128];
	char c;
	unsigned long ul = 1;

	alarm(60);
	
	memset((char *)&conf, 0, sizeof(smtp_conf));
	CSmtp();

	/* init */	
	if(conf.mailport==0)
		conf.mailport= 465;
	
	for (;;) {
		c = getopt( argc, argv, "ms:f:r:h:p:U:P:v");
		if (c == EOF || c == 0 || c == 255)
			break;
		switch (c) {
			case 'm':
				conf.mime_style=1;
				break;
			case 'h':
				conf.mailhost=optarg;
				break;
			case 's':
				conf.subject=optarg;
				break;
			case 'f':
				conf.from_addr=optarg;
				break;
			case 'r':
				conf.recipient=optarg;
				break;
			case 'p':
				conf.mailport=atoi(optarg);
				break;
			case 'U':
				conf.username=optarg;
				base64Encode(conf.username, enc_user);
				break;
			case 'P':
				conf.password=optarg;
				base64Encode(conf.password, enc_pw);
				break;
			case 'v':
				verbose=1;
				break;
			default:
				usage();
				exit(1);
				break;
		}
	}

	
	/* check recipient and mailhost */	
	if(conf.recipient==NULL || conf.mailhost==NULL){
		usage();
		exit(1);
	}

	openlog("smtp",0,LOG_SYSLOG);
	
	/*  Determine SMTP server  */
	if (conf.mailhost == NULL) {
		if ((cp = getenv("SMTPSERVER")) != NULL)
	        conf.mailhost = cp;
    	else
    		conf.mailhost = strdup("localhost");
	}else{
        smtplog("2mailhost: %s.port:%d.from:%s-rec:%s\n", 
            conf.mailhost,conf.mailport,conf.from_addr==NULL?"NO from add":conf.from_addr,conf.recipient);
    }

	SetSMTPServer( conf.mailhost,conf.mailport,1);
	if(conf.mailport == 465)
		SetSecurityType(USE_SSL);
	else if(conf.mailport == 587)
		SetSecurityType(USE_TLS);
	else
		SetSecurityType(NO_SECURITY);

	SetLogin(conf.username);
	SetPassword(conf.password);
	set_encode_user(enc_user);
	set_encode_password(enc_pw);
	SetSenderMail(conf.from_addr);
	SetReplyTo(conf.recipient);
	SetSubject(conf.subject);

	Send();

	if(getErrorType()!= CSMTP_NO_ERROR)
	{
		bError = 1;
	}

	if(!bError)
		log("Send E-mail Success!");

	Destructor_CSmtp();

	//DisconnectRemoteServer();

	return 0;
}
