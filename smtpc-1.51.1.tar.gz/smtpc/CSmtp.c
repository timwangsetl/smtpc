////////////////////////////////////////////////////////////////////////////////
// Original class CFastSmtp written by 
// christopher w. backen <immortal@cox.net>
// More details at: http://www.codeproject.com/KB/IP/zsmtp.aspx
// 
// Modifications introduced by Jakub Piwowarczyk:
// 1. name of the class and functions
// 2. new functions added: SendData,ReceiveData and more
// 3. authentication added
// 4. attachments added
// 5 .comments added
// 6. DELAY_IN_MS removed (no delay during sending the message)
// 7. non-blocking mode
// More details at: http://www.codeproject.com/KB/mcpp/CSmtp.aspx
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// SSL/TLS support added by John Tang by making use of OpenSSL: http://www.openssl.org/ 
// More details at: http://www.codeproject.com/KB/IP/smtp_ssl.aspx
//
// PLAIN, CRAM-MD5 and DIGESTMD5 authentication added by David Johns
//
// Revision History:
// - Version 2.4: Updated with fixes reported as of 22 Oct 2015
//     > Fixed issues with files being left opened and buffer not being deleted if an error occurs as discussed here: http://www.codeproject.com/Messages/4651730/Re-File-attachment.aspx
//       - Thanks to Josep Sol�
//     > Fixed issue with opening attachments as discussed here: http://www.codeproject.com/Messages/4640325/File-path-mistakenly-ommitted-from-file-name-when-.aspx
//       - Thanks to Graham
//     > Fixed potential memory leak as discussed here: http://www.codeproject.com/Messages/5010012/Memory-leaks.aspx
//       - Thanks to LahPo
//     > Made total message size limit larger as recommended here: http://stackoverflow.com/questions/22426686/csmtp-wont-send-an-e-mail-attachment-but-without-the-attachment-it-works-fine/28333737#28333737
//       - Thanks to Stanislav
//     > Fixed an issue with incomplete attachment file paths as discussed here: http://www.codeproject.com/Messages/5127588/Re-Attachment-does-not-come.aspx
//       - Thanks to Member 11508846 and Member 11887128
// - Version 2.3: Updated with fixes reported as of 17 Aug 2013
//     > Removed Bcc header so that recipients don't see who it was Bcc'd to as discussed here: http://www.codeproject.com/Messages/4633562/Bcc-and-mail-header.aspx
//       - Thanks to o15s19
//     > Fixed problem with attaching files that have unicode or reserved character filenames as discussed here: http://www.codeproject.com/Messages/4610174/Re-About-snprintf-FileName-255-Attachments-FileId-.aspx
//       - Thanks to uni_gauldoth
//     > Improved the method used for checking attachment file sizes as discussed here: http://www.codeproject.com/Messages/4562481/retreiving-file-size-for-attachments.aspx
//       - Thanks to GKarRacer
//     > Added #include <unistd.h> for linux compiles, which was required for gethostname as discussed here: http://www.codeproject.com/Messages/4551908/Works-on-Linux-CSmtp-cpp-needed-sharpinclude-unist.aspx
//       - Thanks to jim fred
// - Version 2.2: Updated with fixes reported as of 6 May 2013
//     > Fixed check on MsgBody.size() as discussed here: http://www.codeproject.com/Messages/4555663/Incorrect-range-check.aspx
//       - Thanks to GKarRacer
//     > Moved memory allocation and checking if attachments could be opened to before the MAIL command is
//       issued to avoid throwing errors in a place where you can't terminate the connection gracefully without
//       the email being sent corrupted
//     > Changed all sprintf calls to snprintf to add greater security. #define'd snprintf to sprintf_s for
//       MSVC.  Also changed all strcpy to snprintf since that is the only way to use a secure function that
//       is portable between standard C and MSVC since MS re-ordered the arguments between strcpy and
//       strcpy_s
//     > Fixed issue with SayQuit that could lead to infinite loop discussed here: http://www.codeproject.com/Messages/4451901/exception-in-SayQuit-could-lead-to-infinite-loop.aspx
//       - Thanks to jcyangzh!
//     > Fixed issue with AUTH PLAIN implementation discussed here: http://www.codeproject.com/Messages/4433069/looks-like-a-bug-in-plain-auth.aspx
//       - Thanks to sbrytskyy!
// - Version 2.1: Updated with fixes reported as of 26 Mar 2012
//     > Fixed issue in main.cpp with referring to USE_TLS in the wrong scope discussed here: http://www.codeproject.com/Messages/4151405/Re-USE_SSL-no-member-of-CSmtp.aspx
//       - Thanks to Alan P Brown!
//     > Added modifications to allow it to compile in Debian Linux discussed here: http://www.codeproject.com/Messages/4132697/linux-port-patch.aspx
//       - Thanks to Oleg Dolgov!
//     > Added ability to change the character set, inspired by this post: http://www.codeproject.com/Messages/4238701/Re-The-subject-contains-the-Chinese-letters-could-.aspx
//       - Thanks to LeonHuang0726 and John TWC for the suggestion!
//     > Added ability to request a read receipt by calling SetReadReceipt as proposed here: http://www.codeproject.com/Messages/3938944/Disposition-Notification-To.aspx
//       - Thanks to Gospa for the suggestion!
//     > Added check for Linux when adding paths of attachments in the MIME header as suggested here: http://www.codeproject.com/Messages/4357144/portability-bug-w-attachment-name.aspx
//       - Thanks to Spike!
//     > Switched method of setting private std::string variables to use the = operator as suggested here: http://www.codeproject.com/Messages/4356937/portability-bugs-w-std-string-and-exceptions.aspx
//       - Thanks to Spike!
//     > Added SetLocalHostName function proposed here: http://www.codeproject.com/Messages/4092347/bug-fixes-GetLocalHostName-Send.aspx
//       - Thanks to jerko!
//     > Added the modifications to allow it to compile in Linux described here: http://www.codeproject.com/Messages/3878620/My-vote-of-5.aspx
//       - Thanks to korisk!
//     > Added the fix that corrects behavior when m_sNameFrom is empty described here: http://www.codeproject.com/Messages/4196071/Bug-Mail-sent-by-mail-domain-com.aspx
//       - Thanks to agenua.grupoi68!
// - Version 2.0: Updated to all fixes reported as of 23 Jun 2011:
//     > Added the m_bAuthenticate member variable to be able to disable authentication
//       even though it may be supported by the server. It defaults to true so if it is
//       not set the library will act as it would have before the addition.
//     > Added the ability to pass the security type, m_type, the new m_Authenticate flag,
//       the login and password into the ConnectRemoteServer function. If these new arguments
//       are not included in the call the function will work as it did before.
//     > Added the ability to pass the new m_Authenticate flag into the SetSMTPServer function.
//       If not provided, the function will act as it would before the addition.
//     > Added fix described here: http://www.codeproject.com/Messages/3681792/Bug-when-reading-answer.aspx
//       - Thanks to Martin Kjallman!
//     > Added fixes described here: http://www.codeproject.com/Messages/3707662/Mistakes.aspx
//       - Thanks to Karpov Andrey!
//     > Added fixes described here: http://www.codeproject.com/Messages/3587166/Re-Possible-Solution-To-Misc-EHLO-Errors.aspx
//       - Thanks to Jakub Piwowarczyk!
// - Version 1.9: Started with Revion 6 in code project http://www.codeproject.com/script/Articles/ListVersions.aspx?aid=98355
////////////////////////////////////////////////////////////////////////////////

#include "CSmtp.h"
#include "base64.h"
#include "openssl/err.h"
#include <openssl/ssl.h>

//Add "openssl-0.9.8l\out32" to Additional Library Directories
#pragma comment(lib, "ssleay32.lib")
#pragma comment(lib, "libeay32.lib")


Command_Entry command_list[] = 
{
	{command_INIT,          0,     5*60,  220, SERVER_NOT_RESPONDING},
	{command_EHLO,          5*60,  5*60,  250, COMMAND_EHLO},
	{command_AUTHPLAIN,     5*60,  5*60,  235, COMMAND_AUTH_PLAIN},
	{command_AUTHLOGIN,     5*60,  5*60,  334, COMMAND_AUTH_LOGIN},
	{command_AUTHCRAMMD5,   5*60,  5*60,  334, COMMAND_AUTH_CRAMMD5},
	{command_AUTHDIGESTMD5, 5*60,  5*60,  334, COMMAND_AUTH_DIGESTMD5},
	{command_DIGESTMD5,     5*60,  5*60,  335, COMMAND_DIGESTMD5},
	{command_USER,          5*60,  5*60,  334, UNDEF_XYZ_RESPONSE},
	{command_PASSWORD,      5*60,  5*60,  235, BAD_LOGIN_PASS},
	{command_MAILFROM,      5*60,  5*60,  250, COMMAND_MAIL_FROM},
	{command_RCPTTO,        5*60,  5*60,  250, COMMAND_RCPT_TO},
	{command_DATA,          5*60,  2*60,  354, COMMAND_DATA},
	{command_DATABLOCK,     3*60,  0,     0,   COMMAND_DATABLOCK},	// Here the valid_reply_code is set to zero because there are no replies when sending data blocks
	{command_DATAEND,       3*60,  10*60, 250, MSG_BODY_ERROR},
	{command_QUIT,          5*60,  5*60,  221, COMMAND_QUIT},
	{command_STARTTLS,      5*60,  5*60,  220, COMMAND_EHLO_STARTTLS}
};

Command_Entry* FindCommandEntry(SMTP_COMMAND command)
{
	Command_Entry* pEntry = NULL;
	int i;
	for( i = 0; i < sizeof(command_list)/sizeof(command_list[0]); ++i)
	{
		if(command_list[i].command == command)
		{
			pEntry = &command_list[i];
			break;
		}
	}
	assert(pEntry != NULL);
	return pEntry;
}

// A simple string match
bool IsKeywordSupported(const char* response, const char* keyword)
{
	assert(response != NULL && keyword != NULL);
	if(response == NULL || keyword == NULL)
		return false;
	int res_len = strlen(response);
	int key_len = strlen(keyword);
	if(res_len < key_len)
		return false;
	int pos = 0;
	for(; pos < res_len - key_len + 1; ++pos)
	{
		if(_strnicmp(keyword, response+pos, key_len) == 0)
		{
			if(pos > 0 &&
				(response[pos - 1] == '-' ||
				 response[pos - 1] == ' ' ||
				 response[pos - 1] == '='))
			{
				if(pos+key_len < res_len)
				{
					if(response[pos+key_len] == ' ' ||
					   response[pos+key_len] == '=')
					{
						return true;
					}
					else if(pos+key_len+1 < res_len)
					{
						if(response[pos+key_len] == '\r' &&
						   response[pos+key_len+1] == '\n')
						{
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}
SMTP_SECURITY_TYPE GetSecurityType(void)
{
	return m_type;
}
void SetSecurityType(SMTP_SECURITY_TYPE type)
{
	m_type = type; 
}

CSmtpError status_err = CSMTP_NO_ERROR;
void setErrorType(CSmtpError err)
{
	status_err =  err;
	smtplog("ErrorType:%d\n",status_err);
}
CSmtpError getErrorType(void)
{
	return status_err;
}
unsigned char* CharToUnsignedChar(const char *strIn)
{
	unsigned char *strOut;

	unsigned long length, i;
	length = strlen(strIn);

	strOut = malloc(sizeof(char)*(length+1));
	if(!strOut) 
		return NULL;

	for(i=0; i<length; i++) 
		strOut[i] = (unsigned char) strIn[i];
	strOut[length]='\0';

	return strOut;
}

void CSmtp(void)
{
	hSocket = INVALID_SOCKET;
	m_bConnected = false;
	m_iSMTPSrvPort = 0;
	m_bAuthenticate = true;


	char hostname[255];
	if(gethostname((char *) &hostname, 255) == SOCKET_ERROR) 
		setErrorType(WSA_HOSTNAME);

	//m_sLocalHostName = hostname;
	
	if((RecvBuf = malloc( sizeof(char)*BUFFER_SIZE)) == NULL)
		setErrorType(LACK_OF_MEMORY);
	
	if((SendBuf = malloc( sizeof(char)*BUFFER_SIZE)) == NULL)
		setErrorType(LACK_OF_MEMORY);

	m_type = NO_SECURITY;
	m_ctx = NULL;
	m_ssl = NULL;
	m_bHTML = false;
	m_bReadReceipt = false;

	m_sCharSet = "utf-8";
}

Destructor_CSmtp(void)
{
    if(m_bConnected) 
        DisconnectRemoteServer();
    if(SendBuf)
    {
        free(SendBuf);
		SendBuf = NULL;
	}
    if(RecvBuf)
    {
        free(RecvBuf);
        RecvBuf = NULL;
    }

    CleanupOpenSSL();
}

void Send(void)
{
	unsigned int i,rcpt_count,res,FileId;
	FILE* hFile = NULL;
	unsigned long int FileSize,TotalSize,MsgPart;
	//string FileName,EncodedFileName;
	char *pos;
	char buf[BUFSIZ];

	// ***** CONNECTING TO SMTP SERVER *****
	// connecting to remote host if not already connected:
	if(hSocket==INVALID_SOCKET)
	{
		if(!ConnectRemoteServer(m_sSMTPSrvName, m_iSMTPSrvPort, m_type, m_bAuthenticate,m_sLogin,m_sPassword))
			setErrorType(WSA_INVALID_SOCKET);
	}

	// ***** SENDING E-MAIL *****
	// MAIL <SP> FROM:<reverse-path> <CRLF>
	if(strlen(m_sMailFrom)== 0)
		setErrorType(UNDEF_MAIL_FROM);

	Command_Entry* pEntry = FindCommandEntry(command_MAILFROM);
    SendBuf[0]='\0';
	snprintf(SendBuf, BUFFER_SIZE, "MAIL FROM:<%s>\r\n", m_sMailFrom);
	SendData(pEntry);
	ReceiveResponse(pEntry);

	// RCPT <SP> TO:<forward-path> <CRLF>
	pEntry = FindCommandEntry(command_RCPTTO);
    SendBuf[0]='\0';
	snprintf(SendBuf, BUFFER_SIZE, "RCPT TO:<%s>\r\n", m_sReplyTo);
	SendData(pEntry);
	ReceiveResponse(pEntry);
	
	pEntry = FindCommandEntry(command_DATA);
	// DATA <CRLF>
    SendBuf[0]='\0';
	snprintf(SendBuf, BUFFER_SIZE, "DATA\r\n");
	SendData(pEntry);
	ReceiveResponse(pEntry);
	
	pEntry = FindCommandEntry(command_DATABLOCK);

	// send header(s)
    SendBuf[0]='\0';
	FormatHeader(SendBuf);
	SendData(pEntry);

	// send text message
	/* Give out Message body. */
    SendBuf[0]='\0';
	while (fgets(buf, sizeof(buf), stdin)) {
		buf[strlen(buf)-1] = 0;
		if (strcmp(buf, ".") == 0)
			strcat(SendBuf, "..\r\n");
		else{ 
			strcat(SendBuf, buf);
			strcat(SendBuf, "\r\n");
		}
	}

	SendData(pEntry);

	pEntry = FindCommandEntry(command_DATAEND);
	// <CRLF> . <CRLF>
	snprintf(SendBuf, BUFFER_SIZE, "\r\n.\r\n");

	SendData(pEntry);
	ReceiveResponse(pEntry);

	return;
}

bool ConnectRemoteServer( char* szServer,  unsigned short nPort_/*=0*/, 
								SMTP_SECURITY_TYPE securityType/*=DO_NOT_SET*/,
								bool authenticate/*=true*/,  char* login/*=NULL*/,
								 char* password/*=NULL*/)
{
	unsigned short nPort = 0;
	LPSERVENT lpServEnt;
	SOCKADDR_IN sockAddr;
	unsigned long ul = 1;
	fd_set fdwrite,fdexcept;
	struct timeval timeout;
	int res = 0;


	{
		timeout.tv_sec = TIME_IN_SEC;
		timeout.tv_usec = 0;

		hSocket = INVALID_SOCKET;

		if((hSocket = socket(PF_INET, SOCK_STREAM,0)) == INVALID_SOCKET)
			setErrorType(WSA_INVALID_SOCKET);

		if(nPort_ != 0)
			nPort = htons(nPort_);
		else
			nPort = htons(25);
				
		sockAddr.sin_family = AF_INET;
		sockAddr.sin_port = nPort;
		if((sockAddr.sin_addr.s_addr = inet_addr(szServer)) == INADDR_NONE)
		{
			LPHOSTENT host;
				
			host = gethostbyname(szServer);
			if (host)
				memcpy(&sockAddr.sin_addr,host->h_addr_list[0],host->h_length);
			else
			{
				close(hSocket);
				setErrorType(WSA_GETHOSTBY_NAME_ADDR);
			}				
		}

		// start non-blocking mode for socket:
		if(ioctl(hSocket,FIONBIO, (unsigned long*)&ul) == SOCKET_ERROR)
		{
			close(hSocket);
			setErrorType(WSA_IOCTLSOCKET);
		}

		if(connect(hSocket,(LPSOCKADDR)&sockAddr,sizeof(sockAddr)) == SOCKET_ERROR)
		{
			if(errno != EINPROGRESS)
			{
				close(hSocket);
				setErrorType(WSA_CONNECT);
			}
		}
		else
			return true;

		while(true)
		{
			FD_ZERO(&fdwrite);
			FD_ZERO(&fdexcept);

			FD_SET(hSocket,&fdwrite);
			FD_SET(hSocket,&fdexcept);

			if((res = select(hSocket+1,NULL,&fdwrite,&fdexcept,&timeout)) == SOCKET_ERROR)
			{
				close(hSocket);
				setErrorType(WSA_SELECT);
			}

			if(!res)
			{
				close(hSocket);
				setErrorType(SELECT_TIMEOUT);
			}
			if(res && FD_ISSET(hSocket,&fdwrite))
				break;
			if(res && FD_ISSET(hSocket,&fdexcept))
			{
				close(hSocket);
				setErrorType(WSA_SELECT);
			}
		} // while

		FD_CLR(hSocket,&fdwrite);
		FD_CLR(hSocket,&fdexcept);

		if(securityType!=DO_NOT_SET) 
			SetSecurityType(securityType);
		if(GetSecurityType() == USE_TLS || GetSecurityType() == USE_SSL)
		{
			InitOpenSSL();
			if(GetSecurityType() == USE_SSL)
			{
				OpenSSLConnect();
			}
		}

		Command_Entry* pEntry = FindCommandEntry(command_INIT);
		ReceiveResponse(pEntry);

		SayHello();

		if(GetSecurityType() == USE_TLS)
		{
			StartTls();
			SayHello();
		}

		if(authenticate && IsKeywordSupported(RecvBuf, "AUTH") == true)
		{
			if(login)
				SetLogin(login);
			if(strlen(m_sLogin) == 0)
				setErrorType(UNDEF_LOGIN);

			if(password)
				SetPassword(password);
			if(strlen(m_sPassword)==0)
				setErrorType(UNDEF_PASSWORD);

			if(IsKeywordSupported(RecvBuf, "LOGIN") == true)
			{
				smtplog("LOGIN:%s\n",RecvBuf);

				pEntry = FindCommandEntry(command_AUTHLOGIN);
				snprintf(SendBuf, BUFFER_SIZE, "AUTH LOGIN\r\n");
				SendData(pEntry);
				ReceiveResponse(pEntry);

				// send login:
				pEntry = FindCommandEntry(command_USER);
				snprintf(SendBuf, BUFFER_SIZE, "%s\r\n",enc_user);
				SendData(pEntry);
				ReceiveResponse(pEntry);
				
				// send password:
				pEntry = FindCommandEntry(command_PASSWORD);
				snprintf(SendBuf, BUFFER_SIZE, "%s\r\n",enc_pw);
				SendData(pEntry);
				ReceiveResponse(pEntry);
			}
			else if(IsKeywordSupported(RecvBuf, "PLAIN") == true)
			{
				smtplog("PLAIN:%s\n",RecvBuf);

				pEntry = FindCommandEntry(command_AUTHPLAIN);
				snprintf(SendBuf, BUFFER_SIZE, "%s^%s^%s", m_sLogin, m_sLogin, m_sPassword);
				unsigned int length = strlen(SendBuf);
				unsigned char *ustrLogin = CharToUnsignedChar(SendBuf);
				unsigned int i;
				for(i=0; i<length; i++)
				{
					if(ustrLogin[i]==94) ustrLogin[i]=0;
				}
				unsigned int out_len;
				char *encoded_login = base64_encode(ustrLogin, length,&out_len);

				free(ustrLogin);
				if(encoded_login != NULL)
					snprintf(SendBuf, BUFFER_SIZE, "AUTH PLAIN %s\r\n", encoded_login);
				free(encoded_login);
				SendData(pEntry);
				ReceiveResponse(pEntry);
			}
			else if(IsKeywordSupported(RecvBuf, "CRAM-MD5") == true)
			{
				smtplog("CRAM-md5:%s\n",RecvBuf);

				pEntry = FindCommandEntry(command_AUTHCRAMMD5);
				snprintf(SendBuf, BUFFER_SIZE, "AUTH CRAM-MD5\r\n");
				SendData(pEntry);
				ReceiveResponse(pEntry);
				unsigned int enc_len,enc_olen;

				char *encoded_challenge = RecvBuf;
				if(strlen(encoded_challenge) > 4)
					encoded_challenge = (encoded_challenge+4);
				enc_len = strlen(encoded_challenge);
				char *decoded_challenge = base64_decode(encoded_challenge,enc_len,&enc_olen);
				smtplog("CRAM-md5:%s\n",RecvBuf);
				free(decoded_challenge);
#if 0
				/////////////////////////////////////////////////////////////////////
				//test data from RFC 2195
				//decoded_challenge = "<1896.697170952@postoffice.reston.mci.net>";
				//m_sLogin = "tim";
				//m_sPassword = "tanstaaftanstaaf";
				//MD5 should produce b913a602c7eda7a495b4e6e7334d3890
				//should encode as dGltIGI5MTNhNjAyYzdlZGE3YTQ5NWI0ZTZlNzMzNGQzODkw
				/////////////////////////////////////////////////////////////////////

				unsigned char *ustrChallenge = CharToUnsignedChar(decoded_challenge);
				unsigned char *ustrPassword = CharToUnsignedChar(m_sPassword);
				if(!ustrChallenge || !ustrPassword)
					setErrorType(BAD_LOGIN_PASSWORD);

				// if ustrPassword is longer than 64 bytes reset it to ustrPassword=MD5(ustrPassword)
				int passwordLength=strlen(m_sPassword);
				if(passwordLength > 64){
					MD5 md5password;
					md5password.update(ustrPassword, passwordLength);
					md5password.finalize();
					ustrPassword = md5password.raw_digest();
					passwordLength = 16;
				}

				//Storing ustrPassword in pads
				unsigned char ipad[65], opad[65];
				memset(ipad, 0, 64);
				memset(opad, 0, 64);
				memcpy(ipad, ustrPassword, passwordLength);
				memcpy(opad, ustrPassword, passwordLength);

				// XOR ustrPassword with ipad and opad values
				for(int i=0; i<64; i++){
					ipad[i] ^= 0x36;
					opad[i] ^= 0x5c;
				}

				//perform inner MD5
				MD5 md5pass1;
				md5pass1.update(ipad, 64);
				md5pass1.update(ustrChallenge, decoded_challenge.size());
				md5pass1.finalize();
				unsigned char *ustrResult = md5pass1.raw_digest();

				//perform outer MD5
				MD5 md5pass2;
				md5pass2.update(opad, 64);
				md5pass2.update(ustrResult, 16);
				md5pass2.finalize();
				decoded_challenge = md5pass2.hex_digest();

				free(ustrChallenge);
				free(ustrPassword);
				delete[] ustrResult;

				decoded_challenge = m_sLogin + " " + decoded_challenge;
				encoded_challenge = base64_encode(decoded_challenge,strlen(decoded_challenge),&enc_olen);

				snprintf(SendBuf, BUFFER_SIZE, "%s\r\n", encoded_challenge);
				free(encoded_challenge);
				pEntry = FindCommandEntry(command_PASSWORD);
				SendData(pEntry);
				ReceiveResponse(pEntry);
#endif
			}
			else if(IsKeywordSupported(RecvBuf, "DIGEST-MD5") == true)
			{
				pEntry = FindCommandEntry(command_DIGESTMD5);
				snprintf(SendBuf, BUFFER_SIZE, "AUTH DIGEST-MD5\r\n");
				SendData(pEntry);
				ReceiveResponse(pEntry);
				unsigned int md5_len;

				char *encoded_challenge = RecvBuf;
				if(strlen(encoded_challenge) >4)
					encoded_challenge = (encoded_challenge+4);
				char *decoded_challenge = base64_decode(encoded_challenge,strlen(encoded_challenge),&md5_len);
				smtplog("digest-md5:%s\n",decoded_challenge);
				free(decoded_challenge);
#if 0
				/////////////////////////////////////////////////////////////////////
				//Test data from RFC 2831
				//To test jump into authenticate and read this line and the ones down to next test data section
				//decoded_challenge = "realm=\"elwood.innosoft.com\",nonce=\"OA6MG9tEQGm2hh\",qop=\"auth\",algorithm=md5-sess,charset=utf-8";
				/////////////////////////////////////////////////////////////////////
				
				//Get the nonce (manditory)
				int find = decoded_challenge.find("nonce");
				if(find<0)
					setErrorType(BAD_DIGEST_RESPONSE);
				char *nonce = decoded_challenge.substr(find+7);
				find = nonce.find("\"");
				if(find<0)
					setErrorType(BAD_DIGEST_RESPONSE);
				nonce = nonce.substr(0, find);

				//Get the realm (optional)
				char *realm;
				find = decoded_challenge.find("realm");
				if(find>=0){
					realm = decoded_challenge.substr(find+7);
					find = realm.find("\"");
					if(find<0)
						setErrorType(BAD_DIGEST_RESPONSE);
					realm = realm.substr(0, find);
				}

				//Create a cnonce
				char cnonce[17], nc[9];
				snprintf(cnonce, 17, "%x", (unsigned int) time(NULL));

				//Set nonce count
				snprintf(nc, 9, "%08d", 1);

				//Set QOP
				char *qop = "auth";

				//Get server address and set uri
				//Skip this step during test

				int len;
				struct sockaddr_storage addr;
				len = sizeof addr;
				if(!getpeername(hSocket, (struct sockaddr*)&addr, &len))
					setErrorType(BAD_SERVER_NAME);

				struct sockaddr_in *s = (struct sockaddr_in *)&addr;
				std::string uri =inet_ntoa(s->sin_addr);
				uri = "smtp/" + uri;

				/////////////////////////////////////////////////////////////////////
				//test data from RFC 2831
				//m_sLogin = "chris";
				//m_sPassword = "secret";
				//snprintf(cnonce, 17, "OA6MHXh6VqTrRk");
				//uri = "imap/elwood.innosoft.com";
				//Should form the response:
				//    charset=utf-8,username="chris",
				//    realm="elwood.innosoft.com",nonce="OA6MG9tEQGm2hh",nc=00000001,
				//    cnonce="OA6MHXh6VqTrRk",digest-uri="imap/elwood.innosoft.com",
				//    response=d388dad90d4bbd760a152321f2143af7,qop=auth
				//This encodes to:
				//    Y2hhcnNldD11dGYtOCx1c2VybmFtZT0iY2hyaXMiLHJlYWxtPSJlbHdvb2
				//    QuaW5ub3NvZnQuY29tIixub25jZT0iT0E2TUc5dEVRR20yaGgiLG5jPTAw
				//    MDAwMDAxLGNub25jZT0iT0E2TUhYaDZWcVRyUmsiLGRpZ2VzdC11cmk9Im
				//    ltYXAvZWx3b29kLmlubm9zb2Z0LmNvbSIscmVzcG9uc2U9ZDM4OGRhZDkw
				//    ZDRiYmQ3NjBhMTUyMzIxZjIxNDNhZjcscW9wPWF1dGg=
				/////////////////////////////////////////////////////////////////////

				//Calculate digest response
				unsigned char *ustrRealm = CharToUnsignedChar(realm.c_str());
				unsigned char *ustrUsername = CharToUnsignedChar(m_sLogin.c_str());
				unsigned char *ustrPassword = CharToUnsignedChar(m_sPassword.c_str());
				unsigned char *ustrNonce = CharToUnsignedChar(nonce.c_str());
				unsigned char *ustrCNonce = CharToUnsignedChar(cnonce);
				unsigned char *ustrUri = CharToUnsignedChar(uri.c_str());
				unsigned char *ustrNc = CharToUnsignedChar(nc);
				unsigned char *ustrQop = CharToUnsignedChar(qop.c_str());
				if(!ustrRealm || !ustrUsername || !ustrPassword || !ustrNonce || !ustrCNonce || !ustrUri || !ustrNc || !ustrQop)
					setErrorType(BAD_LOGIN_PASSWORD);

				MD5 md5a1a;
				md5a1a.update(ustrUsername, m_sLogin.size());
				md5a1a.update((unsigned char*)":", 1);
				md5a1a.update(ustrRealm, realm.size());
				md5a1a.update((unsigned char*)":", 1);
				md5a1a.update(ustrPassword, m_sPassword.size());
				md5a1a.finalize();
				unsigned char *ua1 = md5a1a.raw_digest();

				MD5 md5a1b;
				md5a1b.update(ua1, 16);
				md5a1b.update((unsigned char*)":", 1);
				md5a1b.update(ustrNonce, nonce.size());
				md5a1b.update((unsigned char*)":", 1);
				md5a1b.update(ustrCNonce, strlen(cnonce));
				//authzid could be added here
				md5a1b.finalize();
				char *a1 = md5a1b.hex_digest();
				
				MD5 md5a2;
				md5a2.update((unsigned char*) "AUTHENTICATE:", 13);
				md5a2.update(ustrUri, uri.size());
				//authint and authconf add an additional line here	
				md5a2.finalize();
				char *a2 = md5a2.hex_digest();

				delete[] ua1;
				ua1 = CharToUnsignedChar(a1);
				unsigned char *ua2 = CharToUnsignedChar(a2);
				
				//compute KD
				MD5 md5;
				md5.update(ua1, 32);
				md5.update((unsigned char*)":", 1);
				md5.update(ustrNonce, nonce.size());
				md5.update((unsigned char*)":", 1);
				md5.update(ustrNc, strlen(nc));
				md5.update((unsigned char*)":", 1);
				md5.update(ustrCNonce, strlen(cnonce));
				md5.update((unsigned char*)":", 1);
				md5.update(ustrQop, qop.size());
				md5.update((unsigned char*)":", 1);
				md5.update(ua2, 32);
				md5.finalize();
				decoded_challenge = md5.hex_digest();

				delete[] ustrRealm;
				delete[] ustrUsername;
				delete[] ustrPassword;
				delete[] ustrNonce;
				delete[] ustrCNonce;
				delete[] ustrUri;
				delete[] ustrNc;
				delete[] ustrQop;
				delete[] ua1;
				delete[] ua2;
				delete[] a1;
				delete[] a2;

				//send the response
				if(strstr(RecvBuf, "charset")>=0) 
					snprintf(SendBuf, BUFFER_SIZE, "charset=utf-8,username=\"%s\"", m_sLogin.c_str());
				else 
					snprintf(SendBuf, BUFFER_SIZE, "username=\"%s\"", m_sLogin.c_str());
				if(!realm.empty()){
					snprintf(RecvBuf, BUFFER_SIZE, ",realm=\"%s\"", realm.c_str());
					strcat(SendBuf, RecvBuf);
				}
				snprintf(RecvBuf, BUFFER_SIZE, ",nonce=\"%s\"", nonce.c_str());
				strcat(SendBuf, RecvBuf);
				snprintf(RecvBuf, BUFFER_SIZE, ",nc=%s", nc);
				strcat(SendBuf, RecvBuf);
				snprintf(RecvBuf, BUFFER_SIZE, ",cnonce=\"%s\"", cnonce);
				strcat(SendBuf, RecvBuf);
				snprintf(RecvBuf, BUFFER_SIZE, ",digest-uri=\"%s\"", uri.c_str());
				strcat(SendBuf, RecvBuf);
				snprintf(RecvBuf, BUFFER_SIZE, ",response=%s", decoded_challenge.c_str());
				strcat(SendBuf, RecvBuf);
				snprintf(RecvBuf, BUFFER_SIZE, ",qop=%s", qop.c_str());
				strcat(SendBuf, RecvBuf);
				unsigned char *ustrDigest = CharToUnsignedChar(SendBuf);
				encoded_challenge = base64_encode(ustrDigest, strlen(SendBuf));
				delete[] ustrDigest;
				snprintf(SendBuf, BUFFER_SIZE, "%s\r\n", encoded_challenge.c_str());
				pEntry = FindCommandEntry(command_DIGESTMD5);
				SendData(pEntry);
				ReceiveResponse(pEntry);

				//Send completion carraige return
				snprintf(SendBuf, BUFFER_SIZE, "\r\n");				
				pEntry = FindCommandEntry(command_PASSWORD);
				SendData(pEntry);
				ReceiveResponse(pEntry);
			#endif
			}
			else 
				setErrorType(LOGIN_NOT_SUPPORTED);
		}
	}

	if(getErrorType()!= CSMTP_NO_ERROR)
	{
		if(RecvBuf[0]=='5' && RecvBuf[1]=='3' && RecvBuf[2]=='0')
			m_bConnected=false;
		DisconnectRemoteServer();

		return false;
	}

	return true;
}

////////////////////////////////////////////////////////////////////////////////
//        NAME: DisconnectRemoteServer
// DESCRIPTION: Disconnects from the SMTP server and closes the socket
//   ARGUMENTS: none
// USES GLOBAL: none
// MODIFIES GL: none
//     RETURNS: void
//      AUTHOR: David Johns
// AUTHOR/DATE: DRJ 2010-08-14
////////////////////////////////////////////////////////////////////////////////
void DisconnectRemoteServer()
{
	if(m_bConnected)
		SayQuit();
	if(hSocket)
	{
		close(hSocket);
	}
	hSocket = INVALID_SOCKET;
}

////////////////////////////////////////////////////////////////////////////////
//        NAME: FormatHeader
// DESCRIPTION: Prepares a header of the message.
//   ARGUMENTS: char* header - formated header string
// USES GLOBAL: Recipients, CCRecipients, BCCRecipients
// MODIFIES GL: none
//     RETURNS: void
//      AUTHOR: Jakub Piwowarczyk
// AUTHOR/DATE: JP 2010-01-28
//							JP 2010-07-07
////////////////////////////////////////////////////////////////////////////////
void FormatHeader(char* header)
{
	// From: <SP> <sender>  <SP> "<" <sender-email> ">" <CRLF>	 
	strcat(header,"From: ");
	strcat(header," <");
	strcat(header,m_sMailFrom);
	strcat(header, ">\r\n");

	// To: <SP> <remote-user-mail> <CRLF>
	strcat(header,"To: ");
	strcat(header, m_sReplyTo);
	strcat(header, "\r\n");

	// Subject: <SP> <subject-text> <CRLF>
	strcat(header, "Subject: ");
	strcat(header, m_sSubject);

	strcat(header, "\r\n");
	
	// MIME-Version: <SP> 1.0 <CRLF>
	strcat(header,"MIME-Version: 1.0\r\n");

	if(m_bHTML) 
		strcat(header, "Content-Type: text/html; charset=\"");
	else 
		strcat(header, "Content-type: text/plain; charset=\"");
	strcat(header, "utf-8");
	strcat(header, "\"\r\n");
	strcat(header,"Content-Transfer-Encoding: 7bit\r\n");
	strcat(SendBuf,"\r\n");

	return;
}

////////////////////////////////////////////////////////////////////////////////
//        NAME: ReceiveData
// DESCRIPTION: Receives a row terminated '\n'.
//   ARGUMENTS: none
// USES GLOBAL: RecvBuf
// MODIFIES GL: RecvBuf
//     RETURNS: void
//      AUTHOR: Jakub Piwowarczyk
// AUTHOR/DATE: JP 2010-01-28
//							JP 2010-07-07
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// MODIFICATION: Receives data as much as possible. Another function ReceiveResponse
//               will ensure the received data contains '\n'
// AUTHOR/DATE:  John Tang 2010-08-01
////////////////////////////////////////////////////////////////////////////////
void ReceiveData(Command_Entry* pEntry)
{
	if(m_ssl != NULL)
	{
		ReceiveData_SSL(m_ssl, pEntry);
		return;
	}
	int res = 0;
	fd_set fdread;
	struct timeval time;

	time.tv_sec = pEntry->recv_timeout;
	time.tv_usec = 0;

	assert(RecvBuf);

	if(RecvBuf == NULL)
		setErrorType(RECVBUF_IS_EMPTY);

	FD_ZERO(&fdread);

	FD_SET(hSocket,&fdread);

	if((res = select(hSocket+1, &fdread, NULL, NULL, &time)) == SOCKET_ERROR)
	{
		FD_CLR(hSocket,&fdread);
		setErrorType(WSA_SELECT);
	}

	if(!res)
	{
		//timeout
		FD_CLR(hSocket,&fdread);
		setErrorType(SERVER_NOT_RESPONDING);
	}

	if(FD_ISSET(hSocket,&fdread))
	{
		res = recv(hSocket,RecvBuf,BUFFER_SIZE,0);
		if(res == SOCKET_ERROR)
		{
			FD_CLR(hSocket,&fdread);
			setErrorType(WSA_RECV);
		}
	}

	FD_CLR(hSocket,&fdread);
	RecvBuf[res] = 0;
	if(res == 0)
	{
		setErrorType(CONNECTION_CLOSED);
	}
}

////////////////////////////////////////////////////////////////////////////////
//        NAME: SendData
// DESCRIPTION: Sends data from SendBuf buffer.
//   ARGUMENTS: none
// USES GLOBAL: SendBuf
// MODIFIES GL: none
//     RETURNS: void
//      AUTHOR: Jakub Piwowarczyk
// AUTHOR/DATE: JP 2010-01-28
////////////////////////////////////////////////////////////////////////////////
void SendData(Command_Entry* pEntry)
{
	if(m_ssl != NULL)
	{
		SendData_SSL(m_ssl, pEntry);
		return;
	}
	int idx = 0,res,nLeft = strlen(SendBuf);
	fd_set fdwrite;
	struct timeval time;

	time.tv_sec = pEntry->send_timeout;
	time.tv_usec = 0;

	assert(SendBuf);

	if(SendBuf == NULL)
		setErrorType(SENDBUF_IS_EMPTY);

	while(nLeft > 0)
	{
		FD_ZERO(&fdwrite);

		FD_SET(hSocket,&fdwrite);

		if((res = select(hSocket+1,NULL,&fdwrite,NULL,&time)) == SOCKET_ERROR)
		{
			FD_CLR(hSocket,&fdwrite);
			setErrorType(WSA_SELECT);
		}

		if(!res)
		{
			//timeout
			FD_CLR(hSocket,&fdwrite);
			setErrorType(SERVER_NOT_RESPONDING);
		}

		if(res && FD_ISSET(hSocket,&fdwrite))
		{
			res = send(hSocket,&SendBuf[idx],nLeft,0);
			if(res == SOCKET_ERROR || res == 0)
			{
				FD_CLR(hSocket,&fdwrite);
				setErrorType(WSA_SEND);
			}
			nLeft -= res;
			idx += res;
		}
	}

	smtplog("senddata:%s\n",SendBuf);
	FD_CLR(hSocket,&fdwrite);
}


////////////////////////////////////////////////////////////////////////////////
//        NAME: GetReplyTo
// DESCRIPTION: Returns m_pcReplyTo string.
//   ARGUMENTS: none
// USES GLOBAL: m_sReplyTo
// MODIFIES GL: none 
//     RETURNS: m_sReplyTo string
//      AUTHOR: Jakub Piwowarczyk
// AUTHOR/DATE: JP 2010-01-28
////////////////////////////////////////////////////////////////////////////////
char* GetReplyTo(void)
{
	return m_sReplyTo;
}

////////////////////////////////////////////////////////////////////////////////
//        NAME: GetMailFrom
// DESCRIPTION: Returns m_pcMailFrom string.
//   ARGUMENTS: none
// USES GLOBAL: m_sMailFrom
// MODIFIES GL: none 
//     RETURNS: m_sMailFrom string
//      AUTHOR: Jakub Piwowarczyk
// AUTHOR/DATE: JP 2010-01-28
////////////////////////////////////////////////////////////////////////////////
char* GetMailFrom(void)
{
	return m_sMailFrom;
}

////////////////////////////////////////////////////////////////////////////////
//        NAME: GetSubject
// DESCRIPTION: Returns m_pcSubject string.
//   ARGUMENTS: none
// USES GLOBAL: m_sSubject
// MODIFIES GL: none 
//     RETURNS: m_sSubject string
//      AUTHOR: Jakub Piwowarczyk
// AUTHOR/DATE: JP 2010-01-28
////////////////////////////////////////////////////////////////////////////////
char*GetSubject(void)
{
	return m_sSubject;
}

void SetCharSet( char *sCharSet)
{
    m_sCharSet = sCharSet;
}

void SetReplyTo(char *ReplyTo)
{
	m_sReplyTo = ReplyTo;
}

void SetReadReceipt(bool requestReceipt)
{
	m_bReadReceipt = requestReceipt;
}

void SetSenderMail(char *EMail)
{
	m_sMailFrom = EMail;
}

void SetSubject(char *Subject)
{
	m_sSubject = Subject;
}
void set_encode_user(char *user)
{
	memcpy(enc_user,user,strlen(user));

}
void set_encode_password(char *passwrd)
{
	memcpy(enc_pw,passwrd,strlen(passwrd));
}

void SetLogin(char *Login)
{
	m_sLogin = Login;
}

void SetPassword(char *Password)
{
	m_sPassword = Password;
}

void SetSMTPServer( char* SrvName,  unsigned short SrvPort, bool authenticate)
{
	m_iSMTPSrvPort = SrvPort;
	m_sSMTPSrvName = SrvName;
	m_bAuthenticate = authenticate;
}

char *GetErrorText(CSmtpError ErrorCode)
{
	switch(ErrorCode)
	{
		case CSMTP_NO_ERROR:
			return "";
		case WSA_STARTUP:
			return "Unable to initialise winsock2";
		case WSA_VER:
			return "Wrong version of the winsock2";
		case WSA_SEND:
			return "Function send() failed";
		case WSA_RECV:
			return "Function recv() failed";
		case WSA_CONNECT:
			return "Function connect failed";
		case WSA_GETHOSTBY_NAME_ADDR:
			return "Unable to determine remote server";
		case WSA_INVALID_SOCKET:
			return "Invalid winsock2 socket";
		case WSA_HOSTNAME:
			return "Function hostname() failed";
		case WSA_IOCTLSOCKET:
			return "Function ioctlsocket() failed";
		case BAD_IPV4_ADDR:
			return "Improper IPv4 address";
		case UNDEF_MSG_HEADER:
			return "Undefined message header";
		case UNDEF_MAIL_FROM:
			return "Undefined mail sender";
		case UNDEF_SUBJECT:
			return "Undefined message subject";
		case UNDEF_RECIPIENTS:
			return "Undefined at least one reciepent";
		case UNDEF_RECIPIENT_MAIL:
			return "Undefined recipent mail";
		case UNDEF_LOGIN:
			return "Undefined user login";
		case UNDEF_PASSWORD:
			return "Undefined user password";
		case BAD_LOGIN_PASSWORD:
			return "Invalid user login or password";
		case BAD_DIGEST_RESPONSE:
			return "Server returned a bad digest MD5 response";
		case BAD_SERVER_NAME:
			return "Unable to determine server name for digest MD5 response";
		case COMMAND_MAIL_FROM:
			return "Server returned error after sending MAIL FROM";
		case COMMAND_EHLO:
			return "Server returned error after sending EHLO";
		case COMMAND_AUTH_PLAIN:
			return "Server returned error after sending AUTH PLAIN";
		case COMMAND_AUTH_LOGIN:
			return "Server returned error after sending AUTH LOGIN";
		case COMMAND_AUTH_CRAMMD5:
			return "Server returned error after sending AUTH CRAM-MD5";
		case COMMAND_AUTH_DIGESTMD5:
			return "Server returned error after sending AUTH DIGEST-MD5";
		case COMMAND_DIGESTMD5:
			return "Server returned error after sending MD5 DIGEST";
		case COMMAND_DATA:
			return "Server returned error after sending DATA";
		case COMMAND_QUIT:
			return "Server returned error after sending QUIT";
		case COMMAND_RCPT_TO:
			return "Server returned error after sending RCPT TO";
		case MSG_BODY_ERROR:
			return "Error in message body";
		case CONNECTION_CLOSED:
			return "Server has closed the connection";
		case SERVER_NOT_READY:
			return "Server is not ready";
		case SERVER_NOT_RESPONDING:
			return "Server not responding";
		case FILE_NOT_EXIST:
			return "Attachment file does not exist";
		case MSG_TOO_BIG:
			return "Message is too big";
		case BAD_LOGIN_PASS:
			return "Bad login or password";
		case UNDEF_XYZ_RESPONSE:
			return "Undefined xyz SMTP response";
		case LACK_OF_MEMORY:
			return "Lack of memory";
		case TIME_ERROR:
			return "time() error";
		case RECVBUF_IS_EMPTY:
			return "RecvBuf is empty";
		case SENDBUF_IS_EMPTY:
			return "SendBuf is empty";
		case OUT_OF_MSG_RANGE:
			return "Specified line number is out of message size";
		case COMMAND_EHLO_STARTTLS:
			return "Server returned error after sending STARTTLS";
		case SSL_PROBLEM:
			return "SSL problem";
		case COMMAND_DATABLOCK:
			return "Failed to send data block";
		case STARTTLS_NOT_SUPPORTED:
			return "The STARTTLS command is not supported by the server";
		case LOGIN_NOT_SUPPORTED:
			return "AUTH LOGIN is not supported by the server";
		default:
			return "Undefined error id";
	}
}

void SayHello(void)
{
	Command_Entry* pEntry = FindCommandEntry(command_EHLO);
	snprintf(SendBuf, BUFFER_SIZE, "EHLO %s\r\n", m_sSMTPSrvName);
	SendData(pEntry);
	ReceiveResponse(pEntry);
	m_bConnected=true;
}

void SayQuit(void)
{
	// ***** CLOSING CONNECTION ****
	Command_Entry* pEntry = FindCommandEntry(command_QUIT);
	// QUIT <CRLF>
	snprintf(SendBuf, BUFFER_SIZE, "QUIT\r\n");
	m_bConnected=false;
	SendData(pEntry);
	ReceiveResponse(pEntry);
}

void StartTls(void)
{
	if(IsKeywordSupported(RecvBuf, "STARTTLS") == false)
	{
		setErrorType(STARTTLS_NOT_SUPPORTED);
	}
	Command_Entry* pEntry = FindCommandEntry(command_STARTTLS);
	snprintf(SendBuf, BUFFER_SIZE, "STARTTLS\r\n");
	SendData(pEntry);
	ReceiveResponse(pEntry);

	OpenSSLConnect();
}

void ReceiveData_SSL(SSL* ssl, Command_Entry* pEntry)
{
	int res = 0;
	int offset = 0;
	fd_set fdread;
	fd_set fdwrite;
	struct timeval time;

	int read_blocked_on_write = 0;

	time.tv_sec = pEntry->recv_timeout;
	time.tv_usec = 0;

	assert(RecvBuf);

	if(RecvBuf == NULL)
		setErrorType(RECVBUF_IS_EMPTY);

	bool bFinish = false;

	while(!bFinish)
	{
		FD_ZERO(&fdread);
		FD_ZERO(&fdwrite);

		FD_SET(hSocket,&fdread);

		if(read_blocked_on_write)
		{
			FD_SET(hSocket, &fdwrite);
		}

		if((res = select(hSocket+1, &fdread, &fdwrite, NULL, &time)) == SOCKET_ERROR)
		{
			FD_ZERO(&fdread);
			FD_ZERO(&fdwrite);
			setErrorType(WSA_SELECT);
		}

		if(!res)
		{
			//timeout
			FD_ZERO(&fdread);
			FD_ZERO(&fdwrite);
			setErrorType(SERVER_NOT_RESPONDING);
		}

		if(FD_ISSET(hSocket,&fdread) || (read_blocked_on_write && FD_ISSET(hSocket,&fdwrite)) )
		{
			while(1)
			{
				read_blocked_on_write=0;

				const int buff_len = 1024;
				char buff[buff_len];

				res = SSL_read(ssl, buff, buff_len);

				int ssl_err = SSL_get_error(ssl, res);
				if(ssl_err == SSL_ERROR_NONE)
				{
					if(offset + res > BUFFER_SIZE - 1)
					{
						FD_ZERO(&fdread);
						FD_ZERO(&fdwrite);
						setErrorType(LACK_OF_MEMORY);
					}
					memcpy(RecvBuf + offset, buff, res);
					offset += res;
					if(SSL_pending(ssl))
					{
						continue;
					}
					else
					{
						bFinish = true;
						break;
					}
				}
				else if(ssl_err == SSL_ERROR_ZERO_RETURN)
				{
					bFinish = true;
					break;
				}
				else if(ssl_err == SSL_ERROR_WANT_READ)
				{
					break;
				}
				else if(ssl_err == SSL_ERROR_WANT_WRITE)
				{
					/* We get a WANT_WRITE if we're
					trying to rehandshake and we block on
					a write during that rehandshake.

					We need to wait on the socket to be 
					writeable but reinitiate the read
					when it is */
					read_blocked_on_write=1;
					break;
				}
				else
				{
					FD_ZERO(&fdread);
					FD_ZERO(&fdwrite);
					setErrorType(SSL_PROBLEM);
				}
			}
		}
	}

	FD_ZERO(&fdread);
	FD_ZERO(&fdwrite);
	RecvBuf[offset] = 0;

	if(offset == 0)
	{
		setErrorType(CONNECTION_CLOSED);
	}
	smtplog("ReceiveData_SSL:%s\n",RecvBuf);

}

void ReceiveResponse(Command_Entry* pEntry)
{
	char *line;
	int reply_code = 0;
	bool bFinish = false;
    int length = 0;
    int rec_len;

    line = malloc(BUFFER_SIZE);
    if(line == NULL)
        smtplog("ReceiveResponse MALLOC fail\n");


	while(!bFinish)
	{
		ReceiveData(pEntry);
		//line = RecvBuf;
        rec_len = strlen(RecvBuf);
        if((length+rec_len) < BUFFER_SIZE){
            length +=snprintf(line+length, strlen(RecvBuf), RecvBuf);
            if(length < 0){
                free(line);
                return;
            }
        }else{
            free(line);
            return;
        }

		size_t len = length;//strlen(line);
        size_t begin = 0;
        size_t offset = 0;


		while(1) // loop for all lines
		{
			while(offset + 1 < len)
			{
				if(line[offset] == '\r' && line[offset+1] == '\n')
					break;
				++offset;
			}
            //smtplog("rec:%d-%d-%d-%d-%s\n",offset,len,begin,rec_len,line);

			if(offset + 1 <= len) // we found a line
			{
				// see if this is the last line
				// the last line must match the pattern: XYZ<SP>*<CRLF> or XYZ<CRLF> where XYZ is a string of 3 digits 
				offset += 2; // skip <CRLF>
				if(offset - begin >= 5)
				{
					if(isdigit(line[begin]) && isdigit(line[begin+1]) && isdigit(line[begin+2]))
					{
						// this is the last line
						if(offset - begin == 5 || line[begin+3] == ' ')
						{
							reply_code = (line[begin]-'0')*100 + (line[begin+1]-'0')*10 + line[begin+2]-'0';
							bFinish = true;
//smtplog("reply_code:%d\n",reply_code);
							break;
						}
					}
				}
				begin = offset;	// try to find next line
			}
			else // we haven't received the last line, so we need to receive more data 
			{
				break;
			}
		}

	}

	snprintf(RecvBuf, BUFFER_SIZE, line);
	smtplog("recResp:%s\n",RecvBuf);
    free(line);

	if(reply_code != pEntry->valid_reply_code)
	{
		setErrorType(pEntry->error);
	}
}

void SendData_SSL(SSL* ssl, Command_Entry* pEntry)
{
	int offset = 0,res,nLeft = strlen(SendBuf);
	fd_set fdwrite;
	fd_set fdread;
	struct timeval time;

	int write_blocked_on_read = 0;

	time.tv_sec = pEntry->send_timeout;
	time.tv_usec = 0;

	assert(SendBuf);

	if(SendBuf == NULL)
		setErrorType(SENDBUF_IS_EMPTY);

	while(nLeft > 0)
	{
		FD_ZERO(&fdwrite);
		FD_ZERO(&fdread);

		FD_SET(hSocket,&fdwrite);

		if(write_blocked_on_read)
		{
			FD_SET(hSocket, &fdread);
		}

		if((res = select(hSocket+1,&fdread,&fdwrite,NULL,&time)) == SOCKET_ERROR)
		{
			FD_ZERO(&fdwrite);
			FD_ZERO(&fdread);
			setErrorType(WSA_SELECT);
		}

		if(!res)
		{
			//timeout
			FD_ZERO(&fdwrite);
			FD_ZERO(&fdread);
			setErrorType(SERVER_NOT_RESPONDING);
		}

		if(FD_ISSET(hSocket,&fdwrite) || (write_blocked_on_read && FD_ISSET(hSocket, &fdread)) )
		{
			write_blocked_on_read=0;

			/* Try to write */
			res = SSL_write(ssl, SendBuf+offset, nLeft);
	          
			switch(SSL_get_error(ssl,res))
			{
			  /* We wrote something*/
			  case SSL_ERROR_NONE:
				nLeft -= res;
				offset += res;
				break;
	              
				/* We would have blocked */
			  case SSL_ERROR_WANT_WRITE:
				break;

				/* We get a WANT_READ if we're
				   trying to rehandshake and we block on
				   write during the current connection.
	               
				   We need to wait on the socket to be readable
				   but reinitiate our write when it is */
			  case SSL_ERROR_WANT_READ:
				write_blocked_on_read=1;
				break;
	              
				  /* Some other error */
			  default:	      
				FD_ZERO(&fdread);
				FD_ZERO(&fdwrite);
				setErrorType(SSL_PROBLEM);
			}

		}
	}

	//smtplog("SendData:%s\n",SendBuf);
	FD_ZERO(&fdwrite);
	FD_ZERO(&fdread);
}

void InitOpenSSL()
{
	SSL_library_init();
	SSL_load_error_strings();
	m_ctx = SSL_CTX_new (SSLv23_client_method());
	if(m_ctx == NULL)
		setErrorType(SSL_PROBLEM);
}

void OpenSSLConnect()
{
	if(m_ctx == NULL)
		setErrorType(SSL_PROBLEM);
	m_ssl = SSL_new (m_ctx);   
	if(m_ssl == NULL)
		setErrorType(SSL_PROBLEM);
	SSL_set_fd (m_ssl, (int)hSocket);
    SSL_set_mode(m_ssl, SSL_MODE_AUTO_RETRY);

	int res = 0;
	fd_set fdwrite;
	fd_set fdread;
	int write_blocked = 0;
	int read_blocked = 0;

	struct timeval time;
	time.tv_sec = TIME_IN_SEC;
	time.tv_usec = 0;

	while(1)
	{
		FD_ZERO(&fdwrite);
		FD_ZERO(&fdread);

		if(write_blocked)
			FD_SET(hSocket, &fdwrite);
		if(read_blocked)
			FD_SET(hSocket, &fdread);

		if(write_blocked || read_blocked)
		{
			write_blocked = 0;
			read_blocked = 0;
			if((res = select(hSocket+1,&fdread,&fdwrite,NULL,&time)) == SOCKET_ERROR)
			{
				FD_ZERO(&fdwrite);
				FD_ZERO(&fdread);
				setErrorType(WSA_SELECT);
			}
			if(!res)
			{
				//timeout
				FD_ZERO(&fdwrite);
				FD_ZERO(&fdread);
				setErrorType(SERVER_NOT_RESPONDING);
			}
		}
		res = SSL_connect(m_ssl);
		switch(SSL_get_error(m_ssl, res))
		{
		  case SSL_ERROR_NONE:
			FD_ZERO(&fdwrite);
			FD_ZERO(&fdread);
			return;
			break;
              
		  case SSL_ERROR_WANT_WRITE:
			write_blocked = 1;
			break;

		  case SSL_ERROR_WANT_READ:
			read_blocked = 1;
			break;
              
		  default:	      
			FD_ZERO(&fdwrite);
			FD_ZERO(&fdread);
			setErrorType(SSL_PROBLEM);
		}
	}
}

void CleanupOpenSSL()
{
	if(m_ssl != NULL)
	{
		SSL_shutdown (m_ssl);  /* send SSL/TLS close_notify */
		SSL_free (m_ssl);
		m_ssl = NULL;
	}
	if(m_ctx != NULL)
	{
		SSL_CTX_free (m_ctx);	
		m_ctx = NULL;
		ERR_remove_state(0);
		ERR_free_strings();
		EVP_cleanup();
		CRYPTO_cleanup_all_ex_data();
	}
}
