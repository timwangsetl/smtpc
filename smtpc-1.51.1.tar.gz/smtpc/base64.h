#include <string.h>

#ifndef _BASE64_H_
#define _BASE64_H_

unsigned char * base64_encode(unsigned char *src, size_t len,
			      size_t *out_len);
unsigned char * base64_decode(unsigned char *src, size_t len,
			      size_t *out_len);

#endif
